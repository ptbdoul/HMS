// Run locally only: SUPABASE_URL=... SUPABASE_SERVICE_ROLE_KEY=... DEMO_PASSWORD=... npx tsx scripts/seed-users.ts
// Never import this from app code. The service-role key must never reach the browser.
import { createClient } from "@supabase/supabase-js";

const url = process.env.SUPABASE_URL;
const key = process.env.SUPABASE_SERVICE_ROLE_KEY;
const password = process.env.DEMO_PASSWORD;
if (!url || !key || !password) throw new Error("Set SUPABASE_URL, SUPABASE_SERVICE_ROLE_KEY, DEMO_PASSWORD");
if (process.env.ALLOW_SEED !== "yes") throw new Error("Set ALLOW_SEED=yes to confirm this is a dev project");

const admin = createClient(url, key, { auth: { persistSession: false } });
const users = [
  ["admin@hms.test", "Demo Admin", "admin"],
  ["doctor@hms.test", "Dr. Demo", "doctor"],
  ["nurse@hms.test", "Nurse Demo", "nurse"],
  ["frontdesk@hms.test", "Reception Demo", "receptionist"],
] as const;

for (const [email, full_name, role] of users) {
  const { data, error } = await admin.auth.admin.createUser({
    email, password, email_confirm: true, user_metadata: { full_name },
  });
  if (error) { console.error(email, error.message); continue; }
  // Role is set server-side here; signup trigger always creates 'patient'.
  const { error: e2 } = await admin.from("profiles").update({ role }).eq("id", data.user.id);
  console.log(email, e2 ? e2.message : `ok (${role})`);
}
