-- Core schema. Every table has RLS enabled in the next migration.
create extension if not exists pgcrypto;
create extension if not exists btree_gist;

create type public.app_role as enum ('admin','doctor','nurse','receptionist','patient');
create type public.appt_status as enum ('scheduled','checked_in','completed','cancelled','no_show');
create type public.invoice_status as enum ('draft','issued','paid','void');

create table public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  full_name text not null default '',
  role public.app_role not null default 'patient',
  active boolean not null default true,
  created_at timestamptz not null default now()
);

create table public.patients (
  id uuid primary key default gen_random_uuid(),
  user_id uuid unique references auth.users(id) on delete set null,
  mrn text not null unique default ('MRN-' || upper(substr(gen_random_uuid()::text, 1, 8))),
  full_name text not null,
  date_of_birth date not null,
  sex text check (sex in ('female','male','other')),
  phone text,
  email text,
  address text,
  emergency_contact text,
  created_at timestamptz not null default now()
);

create table public.appointments (
  id uuid primary key default gen_random_uuid(),
  patient_id uuid not null references public.patients(id) on delete restrict,
  doctor_id uuid not null references public.profiles(id) on delete restrict,
  starts_at timestamptz not null,
  ends_at timestamptz not null,
  status public.appt_status not null default 'scheduled',
  reason text,
  created_at timestamptz not null default now(),
  check (ends_at > starts_at),
  -- no double-booking a doctor
  exclude using gist (doctor_id with =, tstzrange(starts_at, ends_at) with &&)
    where (status not in ('cancelled','no_show'))
);

create table public.encounters (
  id uuid primary key default gen_random_uuid(),
  patient_id uuid not null references public.patients(id) on delete restrict,
  doctor_id uuid not null references public.profiles(id) on delete restrict,
  appointment_id uuid references public.appointments(id) on delete set null,
  complaint text,
  diagnosis text,
  treatment_notes text,
  created_at timestamptz not null default now()
);

create table public.invoices (
  id uuid primary key default gen_random_uuid(),
  patient_id uuid not null references public.patients(id) on delete restrict,
  encounter_id uuid references public.encounters(id) on delete set null,
  amount_cents integer not null check (amount_cents >= 0),
  status public.invoice_status not null default 'draft',
  issued_at timestamptz,
  created_at timestamptz not null default now()
);

create table public.audit_log (
  id bigint generated always as identity primary key,
  actor_id uuid,
  action text not null,
  table_name text not null,
  row_id uuid,
  at timestamptz not null default now()
);

create index on public.appointments (doctor_id, starts_at);
create index on public.appointments (patient_id);
create index on public.encounters (patient_id);
create index on public.invoices (patient_id);
create index on public.patients (user_id);
