-- Role helpers. SECURITY DEFINER so policies can read profiles without recursion.
create or replace function public.current_app_role()
returns public.app_role language sql stable security definer set search_path = public as $$
  select role from public.profiles where id = auth.uid() and active
$$;

create or replace function public.has_role(variadic roles public.app_role[])
returns boolean language sql stable security definer set search_path = public as $$
  select coalesce(public.current_app_role() = any(roles), false)
$$;

create or replace function public.owns_patient(pid uuid)
returns boolean language sql stable security definer set search_path = public as $$
  select exists (select 1 from public.patients where id = pid and user_id = auth.uid())
$$;

revoke execute on function public.current_app_role(), public.has_role(public.app_role[]), public.owns_patient(uuid) from public, anon;
grant execute on function public.current_app_role(), public.has_role(public.app_role[]), public.owns_patient(uuid) to authenticated;

-- New signups are ALWAYS 'patient'. Role is never read from client-supplied metadata.
create or replace function public.handle_new_user()
returns trigger language plpgsql security definer set search_path = public as $$
begin
  insert into public.profiles (id, full_name)
  values (new.id, coalesce(new.raw_user_meta_data->>'full_name', ''));
  return new;
end $$;
create trigger on_auth_user_created after insert on auth.users
  for each row execute function public.handle_new_user();

-- Audit trigger (writes bypass RLS; no client insert policy exists on audit_log).
create or replace function public.audit_row()
returns trigger language plpgsql security definer set search_path = public as $$
begin
  insert into public.audit_log (actor_id, action, table_name, row_id)
  values (auth.uid(), tg_op, tg_table_name,
          (coalesce(to_jsonb(new), to_jsonb(old))->>'id')::uuid);
  return coalesce(new, old);
end $$;
create trigger audit_patients   after insert or update or delete on public.patients   for each row execute function public.audit_row();
create trigger audit_encounters after insert or update or delete on public.encounters for each row execute function public.audit_row();
create trigger audit_invoices   after insert or update or delete on public.invoices   for each row execute function public.audit_row();

alter table public.profiles     enable row level security;
alter table public.patients     enable row level security;
alter table public.appointments enable row level security;
alter table public.encounters   enable row level security;
alter table public.invoices     enable row level security;
alter table public.audit_log    enable row level security;

-- profiles: self read; staff read (to pick doctors); only admin writes (blocks role escalation)
create policy profiles_select on public.profiles for select to authenticated
  using (id = auth.uid() or public.has_role('admin','doctor','nurse','receptionist'));
create policy profiles_admin_write on public.profiles for all to authenticated
  using (public.has_role('admin')) with check (public.has_role('admin'));

-- patients
create policy patients_select on public.patients for select to authenticated
  using (user_id = auth.uid() or public.has_role('admin','doctor','nurse','receptionist'));
create policy patients_insert on public.patients for insert to authenticated
  with check (public.has_role('admin','receptionist'));
create policy patients_update on public.patients for update to authenticated
  using (public.has_role('admin','receptionist','nurse','doctor'))
  with check (public.has_role('admin','receptionist','nurse','doctor'));
create policy patients_delete on public.patients for delete to authenticated
  using (public.has_role('admin'));

-- appointments
create policy appts_select on public.appointments for select to authenticated
  using (public.owns_patient(patient_id) or public.has_role('admin','doctor','nurse','receptionist'));
create policy appts_insert on public.appointments for insert to authenticated
  with check (public.has_role('admin','receptionist','doctor'));
create policy appts_update on public.appointments for update to authenticated
  using (public.has_role('admin','receptionist','doctor'))
  with check (public.has_role('admin','receptionist','doctor'));
create policy appts_delete on public.appointments for delete to authenticated
  using (public.has_role('admin'));

-- encounters (clinical): receptionists excluded; only the authoring doctor writes
create policy enc_select on public.encounters for select to authenticated
  using (public.owns_patient(patient_id) or public.has_role('admin','doctor','nurse'));
create policy enc_insert on public.encounters for insert to authenticated
  with check (public.has_role('doctor') and doctor_id = auth.uid());
create policy enc_update on public.encounters for update to authenticated
  using (public.has_role('doctor') and doctor_id = auth.uid())
  with check (public.has_role('doctor') and doctor_id = auth.uid());

-- invoices
create policy inv_select on public.invoices for select to authenticated
  using (public.owns_patient(patient_id) or public.has_role('admin','receptionist'));
create policy inv_write on public.invoices for all to authenticated
  using (public.has_role('admin','receptionist')) with check (public.has_role('admin','receptionist'));

-- audit_log: admin read only. No insert/update/delete policies => denied.
create policy audit_admin_read on public.audit_log for select to authenticated
  using (public.has_role('admin'));

revoke all on all tables in schema public from anon;
