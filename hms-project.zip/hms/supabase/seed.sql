-- FAKE demo data only. Staff accounts are created by scripts/seed-users.ts (needs Auth admin API).
insert into public.patients (full_name, date_of_birth, sex, phone, email) values
 ('Demo Patient One',   '1985-03-14', 'female', '555-0101', 'demo.patient1@example.test'),
 ('Demo Patient Two',   '1972-11-02', 'male',   '555-0102', 'demo.patient2@example.test'),
 ('Demo Patient Three', '1999-07-21', 'other',  '555-0103', 'demo.patient3@example.test')
on conflict do nothing;
