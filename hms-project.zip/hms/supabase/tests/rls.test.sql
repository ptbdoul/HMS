-- pgTAP. Run: supabase test db   (NOT YET RUN)
begin;
select plan(7);

insert into auth.users (id, email) values
 ('00000000-0000-0000-0000-0000000000a1','adm@t.test'),
 ('00000000-0000-0000-0000-0000000000d1','doc@t.test'),
 ('00000000-0000-0000-0000-0000000000f1','desk@t.test'),
 ('00000000-0000-0000-0000-0000000000b1','pat@t.test');
update public.profiles set role='admin' where id='00000000-0000-0000-0000-0000000000a1';
update public.profiles set role='doctor' where id='00000000-0000-0000-0000-0000000000d1';
update public.profiles set role='receptionist' where id='00000000-0000-0000-0000-0000000000f1';
insert into public.patients (id,user_id,full_name,date_of_birth)
 values ('11111111-1111-1111-1111-111111111111','00000000-0000-0000-0000-0000000000b1','P','1990-01-01'),
        ('22222222-2222-2222-2222-222222222222',null,'Other','1991-01-01');
insert into public.encounters (patient_id,doctor_id,diagnosis)
 values ('11111111-1111-1111-1111-111111111111','00000000-0000-0000-0000-0000000000d1','x');

create function pg_temp.as_user(u uuid) returns void language plpgsql as $$
begin
  perform set_config('request.jwt.claims', json_build_object('sub',u,'role','authenticated')::text, true);
  set local role authenticated;
end $$;

select pg_temp.as_user('00000000-0000-0000-0000-0000000000b1');
select is((select count(*) from public.patients)::int, 1, 'patient sees only own record');
select is((select count(*) from public.encounters)::int, 1, 'patient sees own encounter');
select lives_ok($$update public.profiles set role='admin' where id=auth.uid()$$, 'escalation attempt is a silent no-op under RLS');
select is((select count(*) from public.audit_log)::int, 0, 'patient cannot read audit log');

reset role;
select pg_temp.as_user('00000000-0000-0000-0000-0000000000f1');
select is((select count(*) from public.encounters)::int, 0, 'receptionist cannot read clinical notes');

reset role;
select pg_temp.as_user('00000000-0000-0000-0000-0000000000a1');
select cmp_ok((select count(*) from public.audit_log)::int, '>', 0, 'admin reads audit log');

reset role;
select is((select role::text from public.profiles where id='00000000-0000-0000-0000-0000000000b1'), 'patient', 'role unchanged');

select * from finish();
rollback;
