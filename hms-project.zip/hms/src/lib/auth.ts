import { redirect } from "next/navigation";
import { createClient } from "@/lib/supabase/server";

export type Role = "admin" | "doctor" | "nurse" | "receptionist" | "patient";
export type Session = { userId: string; role: Role; fullName: string };

/** Authoritative server-side check. Middleware only checks "logged in"; this checks role. */
export async function requireRole(...allowed: Role[]): Promise<Session> {
  const supabase = await createClient();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) redirect("/login");
  const { data: profile } = await supabase.from("profiles").select("role, full_name, active").eq("id", user.id).single();
  if (!profile || !profile.active || !allowed.includes(profile.role as Role)) redirect("/login?error=forbidden");
  return { userId: user.id, role: profile.role as Role, fullName: profile.full_name };
}
