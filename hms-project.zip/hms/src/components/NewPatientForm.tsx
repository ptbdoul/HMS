"use client";
import { useActionState } from "react";
import { createPatient, type FormState } from "@/app/(app)/patients/actions";

export default function NewPatientForm() {
  const [state, action, pending] = useActionState<FormState, FormData>(createPatient, {});
  return (
    <form action={action} className="grid gap-3 rounded-xl border border-slate-200 bg-white p-4 sm:grid-cols-4">
      <input name="full_name" required placeholder="Full name" className="rounded border border-slate-300 p-2" />
      <input name="date_of_birth" type="date" required className="rounded border border-slate-300 p-2" />
      <select name="sex" className="rounded border border-slate-300 p-2"><option value="">Sex</option><option value="female">Female</option><option value="male">Male</option><option value="other">Other</option></select>
      <button disabled={pending} className="rounded bg-slate-900 p-2 text-white disabled:opacity-50">{pending ? "Saving…" : "Add patient"}</button>
      {state.error && <p role="alert" className="text-sm text-red-700 sm:col-span-4">{state.error}</p>}
      {state.ok && <p className="text-sm text-green-700 sm:col-span-4">Patient added.</p>}
    </form>
  );
}
