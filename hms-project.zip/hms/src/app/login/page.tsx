import { signIn } from "./actions";
const messages: Record<string, string> = { invalid: "Invalid email or password.", missing: "Enter email and password.", forbidden: "Your account does not have access." };

export default async function LoginPage({ searchParams }: { searchParams: Promise<{ error?: string }> }) {
  const { error } = await searchParams;
  return (
    <main className="flex min-h-screen items-center justify-center p-6">
      <form action={signIn} className="w-full max-w-sm space-y-4 rounded-xl border border-slate-200 bg-white p-6 shadow-sm">
        <h1 className="text-xl font-semibold">Hospital Management System</h1>
        {error && <p role="alert" className="rounded bg-red-50 p-2 text-sm text-red-700">{messages[error] ?? "Sign-in failed."}</p>}
        <input name="email" type="email" required autoComplete="email" placeholder="Email" className="w-full rounded border border-slate-300 p-2" />
        <input name="password" type="password" required autoComplete="current-password" placeholder="Password" className="w-full rounded border border-slate-300 p-2" />
        <button className="w-full rounded bg-slate-900 p-2 font-medium text-white">Sign in</button>
      </form>
    </main>
  );
}
