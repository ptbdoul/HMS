import { requireRole } from "@/lib/auth";
import { createClient } from "@/lib/supabase/server";
import NewPatientForm from "@/components/NewPatientForm";

export default async function PatientsPage() {
  const s = await requireRole("admin", "doctor", "nurse", "receptionist");
  const supabase = await createClient();
  const { data: patients, error } = await supabase.from("patients").select("id, mrn, full_name, date_of_birth").order("created_at", { ascending: false }).limit(100);
  const canCreate = s.role === "admin" || s.role === "receptionist";
  return (
    <div className="space-y-4">
      <h1 className="text-2xl font-semibold">Patients</h1>
      {canCreate && <NewPatientForm />}
      {error && <p role="alert" className="text-red-700">Unable to load patients.</p>}
      <div className="overflow-x-auto rounded-xl border border-slate-200 bg-white">
        <table className="w-full text-left text-sm"><thead className="bg-slate-100"><tr><th className="p-3">MRN</th><th className="p-3">Name</th><th className="p-3">DOB</th></tr></thead>
          <tbody>{patients?.map(p => <tr key={p.id} className="border-t border-slate-100"><td className="p-3">{p.mrn}</td><td className="p-3">{p.full_name}</td><td className="p-3">{p.date_of_birth}</td></tr>)}</tbody></table>
      </div>
    </div>
  );
}
