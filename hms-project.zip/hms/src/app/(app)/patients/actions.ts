"use server";
import { revalidatePath } from "next/cache";
import { requireRole } from "@/lib/auth";
import { createClient } from "@/lib/supabase/server";

export type FormState = { error?: string; ok?: boolean };

export async function createPatient(_: FormState, formData: FormData): Promise<FormState> {
  await requireRole("admin", "receptionist"); // layer 1: server-side role check
  const full_name = String(formData.get("full_name") ?? "").trim();
  const date_of_birth = String(formData.get("date_of_birth") ?? "");
  const sex = String(formData.get("sex") ?? "") || null;
  if (full_name.length < 2 || full_name.length > 120) return { error: "Name must be 2–120 characters." };
  if (!/^\d{4}-\d{2}-\d{2}$/.test(date_of_birth) || new Date(date_of_birth) > new Date()) return { error: "Enter a valid past date of birth." };
  if (sex && !["female", "male", "other"].includes(sex)) return { error: "Invalid sex value." };
  const supabase = await createClient();
  const { error } = await supabase.from("patients").insert({ full_name, date_of_birth, sex }); // layer 2: RLS
  if (error) return { error: "Could not save patient." };
  revalidatePath("/patients");
  return { ok: true };
}
