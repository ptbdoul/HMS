import { requireRole } from "@/lib/auth";
import { createClient } from "@/lib/supabase/server";

export default async function AdminPage() {
  await requireRole("admin");
  const supabase = await createClient();
  const [p, a, au] = await Promise.all([
    supabase.from("patients").select("*", { count: "exact", head: true }),
    supabase.from("appointments").select("*", { count: "exact", head: true }),
    supabase.from("audit_log").select("id, action, table_name, at").order("at", { ascending: false }).limit(10),
  ]);
  return (
    <div className="-m-6 min-h-screen bg-gradient-to-br from-slate-900 to-indigo-950 p-6 text-white">
      <h1 className="mb-4 text-2xl font-semibold">Admin dashboard</h1>
      <div className="mb-6 grid gap-4 sm:grid-cols-2">
        <div className="rounded-xl bg-white/10 p-4"><p className="text-sm text-slate-300">Patients</p><p className="text-3xl font-bold">{p.count ?? 0}</p></div>
        <div className="rounded-xl bg-white/10 p-4"><p className="text-sm text-slate-300">Appointments</p><p className="text-3xl font-bold">{a.count ?? 0}</p></div>
      </div>
      <h2 className="mb-2 font-medium">Recent audit events</h2>
      <ul className="space-y-1 text-sm text-slate-200">{au.data?.map(e => <li key={e.id}>{e.at} · {e.action} · {e.table_name}</li>)}</ul>
    </div>
  );
}
