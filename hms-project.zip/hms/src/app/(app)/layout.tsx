import Link from "next/link";
import { requireRole } from "@/lib/auth";
import { signOut } from "@/app/login/actions";

export default async function AppLayout({ children }: { children: React.ReactNode }) {
  const s = await requireRole("admin", "doctor", "nurse", "receptionist");
  return (
    <div className="min-h-screen bg-slate-50">
      <header className="flex items-center justify-between border-b border-slate-200 bg-white px-6 py-3">
        <nav className="flex gap-4 text-sm font-medium">
          <Link href="/patients">Patients</Link>
          {s.role === "admin" && <Link href="/admin">Admin</Link>}
        </nav>
        <form action={signOut} className="flex items-center gap-3 text-sm"><span>{s.fullName} · {s.role}</span><button className="underline">Sign out</button></form>
      </header>
      <main className="p-6">{children}</main>
    </div>
  );
}
